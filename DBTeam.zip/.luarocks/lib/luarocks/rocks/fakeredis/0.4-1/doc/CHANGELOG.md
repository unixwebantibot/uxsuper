# fakeredis CHANGELOG

## v0.3 and earlier

- See Git log.

## v0.4

- Use buzy wait sleep if LuaSocket is not available.
- Support Lua 5.3 without backward compatibility.
