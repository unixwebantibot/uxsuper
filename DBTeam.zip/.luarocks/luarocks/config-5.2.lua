rocks_trees = {
   { name = [[system]], root = [[/root/DBTeam/.luarocks]] }
}
