do local _ = {
  admin_users = {
    {
      203568939,
      "Mamadjoker81"
    },
    {
      259273836,
      "reza_farzami"
    }
  },
  disabled_channels = {},
  enabled_lang = {
    "arabic_lang",
    "catalan_lang",
    "english_lang",
    "galician_lang",
    "italian_lang",
    "persian_lang",
    "portuguese_lang",
    "spanish_lang"
  },
  enabled_plugins = {
    "arabic",
    "bot",
    "commands",
    "export_gban",
    "giverank",
    "id",
    "links",
    "moderation",
    "plugins",
    "rules",
    "settings",
    "spam",
    "version"
  },
  sudo_users = {
    259273836,
    239350998,
    259273836,
    203568939
  }
}
return _
end