do local _ = {
  gbans_users = {}
}
return _
end