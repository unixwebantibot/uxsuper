--------------------------------------------------
--      ____  ____ _____                        --
--     |    \|  _ )_   _|___ ____   __  __      --
--     | |_  )  _ \ | |/ ·__|  _ \_|  \/  |     --
--     |____/|____/ |_|\____/\_____|_/\/\_|     --
--                                              --
--------------------------------------------------
--                                              --
--       Developers: @Josepdal & @MaSkAoS       --
--     Support: @Skneos,  @iicc1 & @serx666     --
--                                              --
--------------------------------------------------

do

function run(msg, matches)
  return 'Unixweb Bot V1 Supergroups\nAn advanced Administration bot based on Unixweb.org/acc \n\nDevelopers: @reza_farzami \nSupport: @FuckL1fe tel: 04446328885 Mobile: 09148655110 \nChannel: @unixweb_org \n\nWebsite: http://unixweb.org\nGNU GPL v2 license.'
end

return {
  patterns = {
    "^#version$"
  }, 
  run = run 
}

end
